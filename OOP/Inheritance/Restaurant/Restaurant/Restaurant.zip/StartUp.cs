﻿using System;
using Restaurant.Beverages;
using Restaurant.Foods;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
