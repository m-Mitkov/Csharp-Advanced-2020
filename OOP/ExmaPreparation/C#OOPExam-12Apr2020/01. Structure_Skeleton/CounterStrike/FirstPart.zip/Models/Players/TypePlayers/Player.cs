﻿using CounterStrike.Models.Guns.Contracts;
using CounterStrike.Models.Players.Contracts;
using CounterStrike.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Models.Players.TypePlayers
{
    public abstract class Player : IPlayer
    {
        private string name;
        private int health;
        private int armor;
        public bool isAlive;
        private IGun gun;

        protected Player(string username, int health, int armor, IGun gun)
        {
            this.Username = username;
            this.Health = health;
            this.Armor = armor;
            this.Gun = gun;
        }

        public string Username
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidPlayerName));
                }

                this.name = value;
            }
        }

        public int Health
        {
            get { return this.health; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidPlayerHealth));
                }

                this.health = value;
            }
        }

        public int Armor
        {
            get { return this.armor; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidPlayerArmor));
                }

                this.armor = value;
            }
        }

        public IGun Gun
        {
            get { return this.gun; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidGun));
                }

                this.gun = value;
            }
        }

        public bool IsAlive
        {
            get { return this.isAlive; }
            set
            {
                if (this.Health < 0)
                {
                    this.isAlive = false;
                }

                else
                {
                    this.isAlive = true;
                }
            }
        }

        public void TakeDamage(int points)
        {
            if (this.Armor - points > 0)
            {
                this.Armor -= points;
            }

            else if (this.Armor - points < 0)
            {
                while (this.Armor >= 0)
                {
                    this.Armor -= 1;
                    points -= 1;
                }

                if (this.Health - points < 0)
                {
                    this.IsAlive = false;
                    this.Health = 0;
                }

                this.Health -= points;
            }
        }
    }
}
