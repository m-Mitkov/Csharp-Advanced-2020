﻿namespace CounterStrike.Models.Maps.TypeMaps
{
    public interface IRepository
    {
    }
}